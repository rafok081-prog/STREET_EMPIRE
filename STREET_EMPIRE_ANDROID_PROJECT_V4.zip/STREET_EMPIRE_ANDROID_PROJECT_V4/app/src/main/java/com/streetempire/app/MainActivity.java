package com.streetempire.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Button;
import android.graphics.Color;
import android.view.Gravity;

public class MainActivity extends Activity {
    GameView game;
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        game=new GameView(this);
        FrameLayout root=new FrameLayout(this);
        root.addView(game);

        TextView hud=new TextView(this);
        hud.setText("Баку • Бульвар\n₼ ∞   STREET EMPIRE V4");
        hud.setTextColor(Color.WHITE); hud.setTextSize(16); hud.setPadding(22,18,12,12);
        root.addView(hud);

        Button cam=new Button(this); cam.setText("1P / 3P");
        FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(170,90,Gravity.TOP|Gravity.RIGHT);
        cp.setMargins(0,16,16,0); root.addView(cam,cp);
        cam.setOnClickListener(v->game.toggleCamera());

        Button map=new Button(this); map.setText("MAP");
        FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(150,90,Gravity.TOP|Gravity.RIGHT);
        mp.setMargins(0,112,16,0); root.addView(map,mp);
        map.setOnClickListener(v->game.toggleMap());

        setContentView(root);
        hideBars();
    }
    void hideBars(){
        if(android.os.Build.VERSION.SDK_INT>=30){
            WindowInsetsController c=getWindow().getInsetsController();
            if(c!=null)c.hide(WindowInsets.Type.statusBars()|WindowInsets.Type.navigationBars());
        }else getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }
    @Override protected void onResume(){super.onResume();game.onResume();}
    @Override protected void onPause(){game.onPause();super.onPause();}
}