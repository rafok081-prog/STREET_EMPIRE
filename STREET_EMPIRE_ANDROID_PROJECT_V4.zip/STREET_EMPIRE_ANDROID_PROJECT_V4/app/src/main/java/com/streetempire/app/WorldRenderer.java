package com.streetempire.app;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import java.nio.*;
import javax.microedition.khronos.opengles.GL10;
import javax.microedition.khronos.egl.EGLConfig;

public class WorldRenderer implements GLSurfaceView.Renderer {
    public volatile boolean firstPerson=false,mapOpen=false;
    public volatile float yaw=0,pitch=-10;
    int program,aPos,aColor,uMvp;
    float[] proj=new float[16],view=new float[16],model=new float[16],mvp=new float[16],pv=new float[16];

    final float[] cube={
      -1,-1,-1, 1,-1,-1, 1,1,-1, -1,-1,-1, 1,1,-1, -1,1,-1,
      -1,-1, 1, 1,-1, 1, 1,1, 1, -1,-1, 1, 1,1, 1, -1,1, 1,
      -1,-1,-1,-1,1,-1,-1,1,1, -1,-1,-1,-1,1,1,-1,-1,1,
       1,-1,-1, 1,1,-1, 1,1,1,  1,-1,-1, 1,1,1, 1,-1,1,
      -1,-1,-1,-1,-1,1,1,-1,1, -1,-1,-1,1,-1,1,1,-1,-1,
      -1,1,-1,-1,1,1,1,1,1, -1,1,-1,1,1,1,1,1,-1
    };
    FloatBuffer vb;
    public void onSurfaceCreated(GL10 g,EGLConfig c){
        GLES20.glClearColor(.18f,.31f,.42f,1); GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        String vs="attribute vec3 p; uniform mat4 mvp; void main(){gl_Position=mvp*vec4(p,1.0);}";
        String fs="precision mediump float; uniform vec4 col; void main(){gl_FragColor=col;}";
        program=GLES20.glCreateProgram(); GLES20.glAttachShader(program,shader(GLES20.GL_VERTEX_SHADER,vs));
        GLES20.glAttachShader(program,shader(GLES20.GL_FRAGMENT_SHADER,fs)); GLES20.glLinkProgram(program);
        aPos=GLES20.glGetAttribLocation(program,"p"); uMvp=GLES20.glGetUniformLocation(program,"mvp");
        aColor=GLES20.glGetUniformLocation(program,"col");
        vb=ByteBuffer.allocateDirect(cube.length*4).order(ByteOrder.nativeOrder()).asFloatBuffer();vb.put(cube).position(0);
    }
    int shader(int t,String s){int x=GLES20.glCreateShader(t);GLES20.glShaderSource(x,s);GLES20.glCompileShader(x);return x;}
    public void onSurfaceChanged(GL10 g,int w,int h){GLES20.glViewport(0,0,w,h);Matrix.perspectiveM(proj,0,62,(float)w/h,.1f,300);}
    public void onDrawFrame(GL10 g){
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT);
        float dist=firstPerson?.2f:8f;
        float rad=(float)Math.toRadians(yaw);
        float ex=(float)Math.sin(rad)*dist, ez=(float)Math.cos(rad)*dist;
        Matrix.setLookAtM(view,0,ex,firstPerson?1.7f:4.0f,ez, 0,1.4f,0, 0,1,0);
        Matrix.multiplyMM(pv,0,proj,0,view,0);
        GLES20.glUseProgram(program);
        // Ground / roads
        draw(0,-1,0,45,.12f,45,.18f,.20f,.19f);
        draw(0,-.84f,0,5,.05f,45,.15f,.16f,.17f);
        draw(0,-.83f,0,45,.05f,5,.15f,.16f,.17f);
        // Baku-inspired blocks / skyline
        for(int x=-4;x<=4;x++)for(int z=-4;z<=4;z++){
            if(x==0||z==0)continue;
            float h=2.2f+((Math.abs(x*13+z*7))%6);
            draw(x*7,h/2-1,z*7,2.2f,h/2,2.2f,.56f,.52f,.45f);
        }
        // Three tower silhouettes near "coast"
        draw(-9,5,-22,1.4f,6,1.4f,.22f,.27f,.34f);
        draw(-5,6,-23,1.4f,7,1.4f,.22f,.27f,.34f);
        draw(-1,5,-22,1.4f,6,1.4f,.22f,.27f,.34f);
        // Player body in 3P
        if(!firstPerson){draw(0,.15f,0,.35f,1.15f,.28f,.08f,.09f,.10f);}
        // traffic blocks
        for(int i=0;i<14;i++){float q=(i-7)*4.4f;draw(q,-.45f,(i%2==0?1.5f:-1.5f),1.1f,.35f,.55f,
            i%3==0?.12f:.65f,i%3==1?.65f:.15f,.18f);}
    }
    void draw(float x,float y,float z,float sx,float sy,float sz,float r,float g,float b){
        Matrix.setIdentityM(model,0);Matrix.translateM(model,0,x,y,z);Matrix.scaleM(model,0,sx,sy,sz);
        Matrix.multiplyMM(mvp,0,pv,0,model,0);
        GLES20.glUniformMatrix4fv(uMvp,1,false,mvp,0);GLES20.glUniform4f(aColor,r,g,b,1);
        vb.position(0);GLES20.glVertexAttribPointer(aPos,3,GLES20.GL_FLOAT,false,0,vb);GLES20.glEnableVertexAttribArray(aPos);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,cube.length/3);
    }
}