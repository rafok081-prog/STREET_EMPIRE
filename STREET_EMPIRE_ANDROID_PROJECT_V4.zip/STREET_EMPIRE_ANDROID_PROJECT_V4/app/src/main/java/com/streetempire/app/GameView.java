package com.streetempire.app;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;

public class GameView extends GLSurfaceView {
    final WorldRenderer renderer;
    float lastX,lastY;
    public GameView(Context c){
        super(c); setEGLContextClientVersion(2);
        renderer=new WorldRenderer(); setRenderer(renderer);
        setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
    }
    public void toggleCamera(){renderer.firstPerson=!renderer.firstPerson;}
    public void toggleMap(){renderer.mapOpen=!renderer.mapOpen;}
    @Override public boolean onTouchEvent(MotionEvent e){
        if(e.getAction()==MotionEvent.ACTION_DOWN){lastX=e.getX();lastY=e.getY();return true;}
        if(e.getAction()==MotionEvent.ACTION_MOVE){
            float dx=e.getX()-lastX, dy=e.getY()-lastY; lastX=e.getX();lastY=e.getY();
            renderer.yaw+=dx*.25f; renderer.pitch=Math.max(-35,Math.min(35,renderer.pitch+dy*.15f));
            return true;
        }
        return true;
    }
}