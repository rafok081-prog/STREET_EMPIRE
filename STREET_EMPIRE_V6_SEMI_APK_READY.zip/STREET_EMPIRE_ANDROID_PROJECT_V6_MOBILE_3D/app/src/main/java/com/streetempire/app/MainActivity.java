package com.streetempire.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    GameView game;
    TextView hud, fps, toast;
    FrameLayout root, menu, settings, dev, map;
    Button action, sprint, camera, phone;
    boolean sprintHeld=false;

    GradientDrawable bg(int color, int radius){
        GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g;
    }
    TextView text(String s,int sp){
        TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(sp); return t;
    }
    Button btn(String s){
        Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setBackground(bg(0xCC151B23,28)); return b;
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        game=new GameView(this);
        root=new FrameLayout(this); root.addView(game);

        hud=text("Баку • Бульвар\n₼ ∞   STREET EMPIRE",16); hud.setPadding(18,14,10,8);
        root.addView(hud,new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.LEFT));

        fps=text("FPS 60",12);
        FrameLayout.LayoutParams fp=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.RIGHT); fp.setMargins(0,14,18,0);
        root.addView(fps,fp);

        LinearLayout top=new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL);
        camera=btn("1P/3P"); Button mapB=btn("КАРТА"); Button setB=btn("⚙"); phone=btn("ТЕЛ");
        top.addView(camera); top.addView(mapB); top.addView(setB); top.addView(phone);
        FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(-2,82,Gravity.TOP|Gravity.CENTER_HORIZONTAL); tp.setMargins(0,12,0,0);
        root.addView(top,tp);

        action=btn("ДЕЙСТВИЕ"); sprint=btn("БЕГ");
        Button brake=btn("ТОРМОЗ");
        FrameLayout.LayoutParams bp2=new FrameLayout.LayoutParams(150,90,Gravity.BOTTOM|Gravity.RIGHT);
        bp2.setMargins(0,0,385,32); root.addView(brake,bp2);
        brake.setOnTouchListener((v,e)->{ if(e.getAction()!=MotionEvent.ACTION_UP) game.renderer.moveZ=-0.65f; else game.renderer.moveZ=0; return true;});
        FrameLayout.LayoutParams ap=new FrameLayout.LayoutParams(190,105,Gravity.BOTTOM|Gravity.RIGHT); ap.setMargins(0,0,20,20);
        root.addView(action,ap);
        FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(150,90,Gravity.BOTTOM|Gravity.RIGHT); sp.setMargins(0,0,220,32);
        root.addView(sprint,sp);

        TextView stick=text("●",54); stick.setGravity(Gravity.CENTER); stick.setBackground(bg(0x552A3440,100));
        FrameLayout.LayoutParams jp=new FrameLayout.LayoutParams(155,155,Gravity.BOTTOM|Gravity.LEFT); jp.setMargins(20,0,0,18);
        root.addView(stick,jp);
        stick.setOnTouchListener((v,e)->{ game.joystick(e,v.getWidth(),v.getHeight()); return true; });

        action.setOnClickListener(v->game.action());
        sprint.setOnTouchListener((v,e)->{ sprintHeld=e.getAction()!=MotionEvent.ACTION_UP&&e.getAction()!=MotionEvent.ACTION_CANCEL; game.sprint=sprintHeld; return true;});
        camera.setOnClickListener(v->game.toggleCamera());
        mapB.setOnClickListener(v->showMap());
        setB.setOnClickListener(v->showSettings());
        phone.setOnClickListener(v->showPhone());

        setContentView(root); hideBars();
        showIntro();
    }

    void showIntro(){
        menu=new FrameLayout(this); menu.setBackgroundColor(0xF2071018);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER); box.setPadding(35,25,35,25);
        TextView city=text("BAKU • AZERBAIJAN",14); city.setGravity(Gravity.CENTER);
        TextView title=text("STREET EMPIRE",38); title.setGravity(Gravity.CENTER);
        TextView sub=text("Бульвар • Ичери-шехер • Низами • Белый город",13); sub.setGravity(Gravity.CENTER);
        Button play=btn("ИГРАТЬ"); Button hero=btn("ВЫБРАТЬ ПЕРСОНАЖА");
        box.addView(city);box.addView(title);box.addView(sub);box.addView(play,new LinearLayout.LayoutParams(430,95));box.addView(hero,new LinearLayout.LayoutParams(430,95));
        menu.addView(box,new FrameLayout.LayoutParams(-1,-1));
        root.addView(menu,new FrameLayout.LayoutParams(-1,-1));
        play.setOnClickListener(v->root.removeView(menu));
        hero.setOnClickListener(v->{ game.nextHero(); toast("Персонаж: "+game.heroName());});
    }

    void showSettings(){
        settings=overlay("НАСТРОЙКИ");
        LinearLayout box=(LinearLayout)settings.getChildAt(0);
        Button cam=btn("Камера: 1-е / 3-е лицо"); cam.setOnClickListener(v->game.toggleCamera());
        Button sens=btn("Чувствительность камеры"); sens.setOnClickListener(v->{game.sensitivity=game.sensitivity>=1.5f?.65f:game.sensitivity+.2f;toast("Чувствительность "+String.format("%.1f",game.sensitivity));});
        Button devB=btn("✓ РАЗРАБОТЧИК"); devB.setOnClickListener(v->showDeveloper());
        Button close=btn("ЗАКРЫТЬ"); close.setOnClickListener(v->root.removeView(settings));
        box.addView(cam);box.addView(sens);box.addView(devB);box.addView(close);
    }

    void showDeveloper(){
        dev=overlay("✓ DEVELOPER");
        LinearLayout box=(LinearLayout)dev.getChildAt(0);
        Button hero=btn("Сменить персонажа"); hero.setOnClickListener(v->{game.nextHero();toast(game.heroName());});
        Button car=btn("Вызвать K1A Sorento"); car.setOnClickListener(v->{game.spawnVehicle(0);toast("K1A Sorento вызван");});
        Button moto=btn("Вызвать мотоцикл"); moto.setOnClickListener(v->{game.spawnVehicle(1);toast("Мотоцикл вызван");});
        Button taxi=btn("Вызвать такси"); taxi.setOnClickListener(v->{game.spawnVehicle(2);toast("Такси вызвано");});
        Button time=btn("+2 игровых часа"); time.setOnClickListener(v->game.addTime(120));
        Button close=btn("ЗАКРЫТЬ"); close.setOnClickListener(v->root.removeView(dev));
        box.addView(hero);box.addView(car);box.addView(moto);box.addView(taxi);box.addView(time);box.addView(close);
    }

    void showMap(){
        map=overlay("КАРТА БАКУ");
        LinearLayout box=(LinearLayout)map.getChildAt(0);
        String[] places={"Бульвар","Ичери-шехер","Низами","Белый город","Нариманов","Хатаи","Байыл"};
        for(String p:places){Button b=btn(p); b.setOnClickListener(v->{game.teleport(((Button)v).getText().toString());root.removeView(map);});box.addView(b);}
        Button close=btn("ЗАКРЫТЬ");close.setOnClickListener(v->root.removeView(map));box.addView(close);
    }

    void showPhone(){
        FrameLayout ph=overlay("ТЕЛЕФОН • КОМАНДЫ");
        LinearLayout box=(LinearLayout)ph.getChildAt(0);
        Button car=btn("Транспорт → K1A Sorento");car.setOnClickListener(v->{game.spawnVehicle(0);toast("Машина рядом");});
        Button bike=btn("Транспорт → Мотоцикл");bike.setOnClickListener(v->{game.spawnVehicle(1);toast("Мотоцикл рядом");});
        Button taxi=btn("Такси → вызвать");taxi.setOnClickListener(v->{game.spawnVehicle(2);toast("Такси едет к тебе");});
        Button close=btn("ЗАКРЫТЬ");close.setOnClickListener(v->root.removeView(ph));
        box.addView(car);box.addView(bike);box.addView(taxi);box.addView(close);
    }

    FrameLayout overlay(String title){
        FrameLayout p=new FrameLayout(this);p.setBackgroundColor(0xE905090E);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setGravity(Gravity.CENTER);box.setPadding(25,18,25,18);
        TextView h=text(title,27);h.setGravity(Gravity.CENTER);box.addView(h,new LinearLayout.LayoutParams(-1,80));
        p.addView(box,new FrameLayout.LayoutParams(620,-1,Gravity.CENTER));root.addView(p,new FrameLayout.LayoutParams(-1,-1));return p;
    }
    void toast(String s){ Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }
    void hideBars(){
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }
    @Override protected void onResume(){super.onResume();game.onResume();}
    @Override protected void onPause(){game.onPause();super.onPause();}
}