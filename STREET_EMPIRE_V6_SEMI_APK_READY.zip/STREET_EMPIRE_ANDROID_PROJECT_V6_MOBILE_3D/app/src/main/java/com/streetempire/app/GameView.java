package com.streetempire.app;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;

public class GameView extends GLSurfaceView {
    final WorldRenderer renderer;
    public boolean sprint=false;
    public int controlMode=0; // 0 on foot, 1 car, 2 motorcycle, 3 aircraft
    public float sensitivity=1f;
    float lastX,lastY;
    public GameView(Context c){
        super(c);setEGLContextClientVersion(2);renderer=new WorldRenderer();setRenderer(renderer);
        setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
    }
    public void joystick(MotionEvent e,int w,int h){
        if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){renderer.moveX=renderer.moveZ=0;return;}
        renderer.moveX=Math.max(-1,Math.min(1,(e.getX()-w/2f)/(w*.35f)));
        renderer.moveZ=Math.max(-1,Math.min(1,(h/2f-e.getY())/(h*.35f)));
        renderer.sprint=sprint;
    }
    public void action(){renderer.action(); controlMode=renderer.inVehicle>=0?1:0;}
    public void toggleCamera(){renderer.firstPerson=!renderer.firstPerson;}
    public void nextHero(){renderer.hero=(renderer.hero+1)%3;}
    public String heroName(){return new String[]{"Джейк Картер","Маркус Рид","Виктор Кейн"}[renderer.hero];}
    public void spawnVehicle(int type){renderer.spawnVehicle(type);}
    public void addTime(float m){renderer.gameMinutes=(renderer.gameMinutes+m)%1440;}
    public void teleport(String p){renderer.teleport(p);}
    @Override public boolean onTouchEvent(MotionEvent e){
        if(e.getAction()==MotionEvent.ACTION_DOWN){lastX=e.getX();lastY=e.getY();return true;}
        if(e.getAction()==MotionEvent.ACTION_MOVE){
            float dx=e.getX()-lastX;lastX=e.getX();lastY=e.getY();
            renderer.yaw+=dx*.22f*sensitivity;return true;
        }return true;
    }
}