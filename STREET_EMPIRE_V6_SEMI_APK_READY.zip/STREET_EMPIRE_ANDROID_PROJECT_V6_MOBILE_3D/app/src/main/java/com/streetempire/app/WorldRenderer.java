package com.streetempire.app;

import android.opengl.*;
import java.nio.*;
import javax.microedition.khronos.opengles.GL10;
import javax.microedition.khronos.egl.EGLConfig;
import java.util.*;

public class WorldRenderer implements GLSurfaceView.Renderer {
 public volatile boolean firstPerson=false,sprint=false;
 public volatile float yaw=0,moveX=0,moveZ=0,gameMinutes=7*60;
 public volatile int hero=0;
 float px=0,pz=0,py=0; public int inVehicle=-1; long last=System.nanoTime();
 int program,aPos,aColor,uMvp; float[] proj=new float[16],view=new float[16],model=new float[16],pv=new float[16],mvp=new float[16];
 FloatBuffer vb;
 static class V {float x,z,a,s;int type;boolean npc=true;V(float X,float Z,float A,float S,int T){x=X;z=Z;a=A;s=S;type=T;}}
 ArrayList<V> vehicles=new ArrayList<>();
 float[] cube={-1,-1,-1,1,-1,-1,1,1,-1,-1,-1,-1,1,1,-1,-1,1,-1,-1,-1,1,1,-1,1,1,1,1,-1,-1,1,1,1,1,-1,1,1,-1,-1,-1,-1,1,-1,-1,1,1,-1,-1,-1,-1,1,1,-1,-1,1,1,-1,-1,1,1,-1,1,1,1,1,-1,-1,1,1,1,1,-1,1,-1,-1,-1,-1,-1,1,1,-1,1,-1,-1,-1,1,-1,1,1,-1,-1,-1,1,1,-1,1,1,1,1,-1,1,-1,1,1,1,1,1,-1};

 public WorldRenderer(){
  for(int i=0;i<28;i++)vehicles.add(new V(-38+(i%10)*8,(i%2==0?2:-2)+(i/10)*18,0,2.4f+(i%4)*.25f,i%7));
 }
 public void onSurfaceCreated(GL10 g,EGLConfig c){
  GLES20.glClearColor(.25f,.43f,.58f,1);GLES20.glEnable(GLES20.GL_DEPTH_TEST);
  String vs="attribute vec3 p;uniform mat4 mvp;void main(){gl_Position=mvp*vec4(p,1.0);}";
  String fs="precision mediump float;uniform vec4 col;void main(){gl_FragColor=col;}";
  program=GLES20.glCreateProgram();GLES20.glAttachShader(program,shader(GLES20.GL_VERTEX_SHADER,vs));GLES20.glAttachShader(program,shader(GLES20.GL_FRAGMENT_SHADER,fs));GLES20.glLinkProgram(program);
  aPos=GLES20.glGetAttribLocation(program,"p");uMvp=GLES20.glGetUniformLocation(program,"mvp");aColor=GLES20.glGetUniformLocation(program,"col");
  vb=ByteBuffer.allocateDirect(cube.length*4).order(ByteOrder.nativeOrder()).asFloatBuffer();vb.put(cube).position(0);
 }
 int shader(int t,String s){int x=GLES20.glCreateShader(t);GLES20.glShaderSource(x,s);GLES20.glCompileShader(x);return x;}
 public void onSurfaceChanged(GL10 g,int w,int h){GLES20.glViewport(0,0,w,h);Matrix.perspectiveM(proj,0,62,(float)w/h,.1f,500);}
 public void onDrawFrame(GL10 g){
  long now=System.nanoTime();float dt=Math.min(.033f,(now-last)/1e9f);last=now;update(dt);
  float hour=gameMinutes/60f;float night=(hour>=19||hour<7)?.13f:.32f;
  GLES20.glClearColor(night,night+.06f,night+.11f,1);GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT);
  float rad=(float)Math.toRadians(yaw),dist=firstPerson?.15f:8.5f;
  float ex=px+(float)Math.sin(rad)*dist,ez=pz+(float)Math.cos(rad)*dist;
  Matrix.setLookAtM(view,0,ex,firstPerson?1.65f:4.3f,ez,px,1.3f,pz,0,1,0);Matrix.multiplyMM(pv,0,proj,0,view,0);
  GLES20.glUseProgram(program);drawWorld();
 }
 void update(float dt){
  gameMinutes=(gameMinutes+dt*3)%1440; // 1 game hour = 20 real minutes
  if(inVehicle>=0){
   V v=vehicles.get(inVehicle);float throttle=moveZ;v.s=throttle*(sprint?10:7);v.a-=moveX*dt*1.7f;
   v.x+=(float)Math.sin(v.a)*v.s*dt;v.z+=(float)Math.cos(v.a)*v.s*dt;px=v.x;pz=v.z;
  } else {
   float speed=sprint?6.2f:3.4f, r=(float)Math.toRadians(yaw);
   float dx=(float)(Math.cos(r)*moveX-Math.sin(r)*moveZ),dz=(float)(Math.sin(r)*moveX+Math.cos(r)*moveZ);
   float nx=px+dx*speed*dt,nz=pz+dz*speed*dt;
   // collision with building blocks; roads remain walkable
   if(!insideBuilding(nx,nz)){px=nx;pz=nz;}
  }
  for(int i=0;i<vehicles.size();i++){V v=vehicles.get(i);if(!v.npc||i==inVehicle)continue;v.x+=(float)Math.sin(v.a)*v.s*dt;v.z+=(float)Math.cos(v.a)*v.s*dt;if(Math.abs(v.x)>48)v.a+=Math.PI;}
 }
 boolean insideBuilding(float x,float z){
  for(int gx=-5;gx<=5;gx++)for(int gz=-5;gz<=5;gz++){if(gx==0||gz==0)continue;float bx=gx*9,bz=gz*9;if(Math.abs(x-bx)<2.7&&Math.abs(z-bz)<2.7)return true;}return false;
 }
 public void action(){
  if(inVehicle>=0){V v=vehicles.get(inVehicle);px=v.x+2;pz=v.z+2;inVehicle=-1;return;}
  float best=3.4f;int bi=-1;for(int i=0;i<vehicles.size();i++){V v=vehicles.get(i);float d=(float)Math.hypot(px-v.x,pz-v.z);if(d<best){best=d;bi=i;}}
  if(bi>=0){inVehicle=bi;vehicles.get(bi).npc=false;}
 }
 public void spawnVehicle(int type){vehicles.add(new V(px+3,pz+2,0,0,type));}
 public void teleport(String p){
  if(p.equals("Бульвар")){px=0;pz=-36;}else if(p.equals("Ичери-шехер")){px=-27;pz=-9;}else if(p.equals("Низами")){px=-9;pz=0;}
  else if(p.equals("Белый город")){px=27;pz=-9;}else if(p.equals("Нариманов")){px=18;pz=27;}else if(p.equals("Хатаи")){px=36;pz=18;}else{px=-27;pz=27;}
 }
 void drawWorld(){
  draw(0,-1,0,55,.1f,55,.22f,.29f,.20f);
  draw(0,-.84f,0,5,.05f,55,.13f,.14f,.15f);draw(0,-.83f,0,55,.05f,5,.13f,.14f,.15f);
  // waterfront / boulevard
  draw(0,-.95f,-50,55,.05f,8,.12f,.37f,.52f);draw(0,-.82f,-40,55,.05f,3,.68f,.61f,.43f);
  for(int gx=-5;gx<=5;gx++)for(int gz=-5;gz<=5;gz++){if(gx==0||gz==0)continue;float h=2.2f+(Math.abs(gx*11+gz*7)%7);draw(gx*9,h/2-1,gz*9,2.6f,h/2,2.6f,.50f+(gx%2)*.04f,.46f,.39f);}
  // Baku skyline cues
  draw(-13,6,-35,1.4f,7,1.4f,.18f,.23f,.30f);draw(-9,7,-36,1.4f,8,1.4f,.18f,.23f,.30f);draw(-5,6,-35,1.4f,7,1.4f,.18f,.23f,.30f);
  for(int i=0;i<vehicles.size();i++){V v=vehicles.get(i);float[] c=vehicleColor(i,v.type);draw(v.x,-.45f,v.z,v.type==1?.45f:1.25f,v.type==1?.35f:.45f,v.type==1?1.2f:.7f,c[0],c[1],c[2]);}
  // varied NPCs
  for(int i=0;i<32;i++){float x=-44+(i%8)*12,z=-31+(i/8)*19;float r=(i%5)*.09f+.18f;draw(x,-.05f,z,.22f,.9f,.22f,r,.22f+(i%3)*.12f,.25f+(i%4)*.08f);}
  if(!firstPerson&&inVehicle<0){float[][] hc={{.08f,.09f,.10f},{.10f,.22f,.38f},{.31f,.18f,.12f}};draw(px,.05f,pz,.32f,1.1f,.28f,hc[hero][0],hc[hero][1],hc[hero][2]);}
 }
 float[] vehicleColor(int i,int type){
  float[][] p={{.08f,.08f,.08f},{.88f,.88f,.85f},{.52f,.54f,.55f},{.20f,.21f,.22f},{.12f,.18f,.28f},{.35f,.10f,.11f}};
  if(type==2)return new float[]{.83f,.68f,.12f};return p[i%p.length];
 }
 void draw(float x,float y,float z,float sx,float sy,float sz,float r,float g,float b){
  Matrix.setIdentityM(model,0);Matrix.translateM(model,0,x,y,z);Matrix.scaleM(model,0,sx,sy,sz);Matrix.multiplyMM(mvp,0,pv,0,model,0);
  GLES20.glUniformMatrix4fv(uMvp,1,false,mvp,0);GLES20.glUniform4f(aColor,r,g,b,1);vb.position(0);GLES20.glVertexAttribPointer(aPos,3,GLES20.GL_FLOAT,false,0,vb);GLES20.glEnableVertexAttribArray(aPos);GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,cube.length/3);
 }
}