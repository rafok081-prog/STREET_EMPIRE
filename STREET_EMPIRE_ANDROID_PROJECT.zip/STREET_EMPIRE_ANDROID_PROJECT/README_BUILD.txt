STREET EMPIRE Android wrapper

Сам файл игры index.html скопирован без изменений.
Проект загружает его локально в Android WebView.

Сборка APK:
  gradle assembleDebug

Результат:
  app/build/outputs/apk/debug/app-debug.apk

Также добавлен GitHub Actions workflow для автоматической сборки APK.
